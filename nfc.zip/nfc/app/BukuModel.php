<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BukuModel extends Model
{
    protected $fillable = [
      'judul',
    'pengarang',
    'tahun',
    'penerbit',
    'cetakan',
    'harga',
    'alamat',
  ];
}
